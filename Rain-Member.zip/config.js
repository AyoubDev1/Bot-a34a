module.exports = {
  bot: {
    owners: ["957769311664111657"],  // اونر
    botID: "1244417164807508010",    // ايدي البوت
    GuildId: "1257769101435338856",   // ايدي السيرفير
    ClientId: "1244417164807508010",    // ايدي البوت
    serverinvte: "https://discord.gg/mBDpaYNH", // انفايت سير
    clientSECRET: "uy91F6RbKzYh_rv7JEB4XWW9iYiivTOT", // سكريت
    callbackURL: "https://exuberant-glow-cork.glitch.me//callback/login", // الكال باك
    TheLinkVerfy : 'https://discord.com/oauth2/authorize?client_id=1244417164807508010&response_type=code&redirect_uri=https%3A%2F%2Fexuberant-glow-cork.glitch.me%2F&scope=guilds.join+gdm.join+guilds.members.read+guilds+email+connections', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '$', 
     TOKEN: ("MTI0NDQxNzE2NDgwNzUwODAxMA.G7stka.LBsagDpGxTG9BP72TmNpnJJLpNtScQDGjI4ukc"),// توكن 
    TraId  : '957769311664111657', // الي يتحوله كريديت
    done : "1257989354899640412",//ايدي روم تمت العملية
    line : "https://cdn.discordapp.com/attachments/1257989470834397295/1268873164876812362/1.jpg?ex=66b29ef9&is=66b14d79&hm=b261e77cb4b874698a0a37a0fa85dd761e7438866b9ae4ca3ccbbffd97a5317e&",//رابط خط السيرفر
    stockimg : "https://cdn.discordapp.com/attachments/1257989470834397295/1268873164876812362/1.jpg?ex=66b29ef9&is=66b14d79&hm=b261e77cb4b874698a0a37a0fa85dd761e7438866b9ae4ca3ccbbffd97a5317e&",//رابط صوره ستوك الاعضاء
      supportimg : "https://cdn.discordapp.com/attachments/1257989470834397295/1268873164876812362/1.jpg?ex=66b29ef9&is=66b14d79&hm=b261e77cb4b874698a0a37a0fa85dd761e7438866b9ae4ca3ccbbffd97a5317e&",//رابط صوره تذكرة الدعم الفني
    ticketimg : "https://cdn.discordapp.com/attachments/1257989470834397295/1268873164876812362/1.jpg?ex=66b29ef9&is=66b14d79&hm=b261e77cb4b874698a0a37a0fa85dd761e7438866b9ae4ca3ccbbffd97a5317e&",//زابط صور تذكرة الشراء
    fedroom : "",//ايدي روم الفيدباك
    clientrole : ""//ايدي رتبه الزباين
  },
  website: {
    PORT: "3001",
  }
}